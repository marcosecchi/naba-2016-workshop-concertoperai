﻿using UnityEngine;
using System.Collections;

namespace TheBitCave.ConcertoPerAI {
	public class ScoreController : MonoBehaviour {

		public ScoreSectionButton[] scoreSectionButtons;

		int _noteIndex = -1;

		void Start() {
			foreach(ScoreSectionButton btn in scoreSectionButtons) {
				btn.IsTempoOnNote = false;
			}
		}

		public void SelectNextNote() {
			if(_noteIndex >= 0)
				scoreSectionButtons[_noteIndex].IsTempoOnNote = false;
			_noteIndex++;
			if(_noteIndex >= scoreSectionButtons.Length)
				_noteIndex = 0;
			scoreSectionButtons[_noteIndex].IsTempoOnNote = true;
		}

		public int GetNoteType() {
			return scoreSectionButtons[_noteIndex].GetNoteIndex();
		}

		public void Reset() {
			scoreSectionButtons[_noteIndex].Reset();
			_noteIndex = -1;
		}
	}
}