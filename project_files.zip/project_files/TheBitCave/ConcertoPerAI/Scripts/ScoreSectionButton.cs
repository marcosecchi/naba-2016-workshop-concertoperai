﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace TheBitCave.ConcertoPerAI {
	
	[RequireComponent(typeof(Image))]
	public class ScoreSectionButton : MonoBehaviour {

		float disabledAlpha = .75f;
		float enabledAlpha = 1;

		public Sprite[] notes;

		public Image image;

		int _noteIndex = 0;

		void Start() {
			image.sprite = notes[0];
		}

		public void SetNextNote() {
			_noteIndex++;
			if(_noteIndex >= notes.Length)
				_noteIndex = 0;
			image.sprite = notes[_noteIndex];
		}

		public int GetNoteIndex() {
			return _noteIndex;
		}

		private bool _isTempoOnNote = false;

		public bool IsTempoOnNote {
			set {
				_isTempoOnNote = value;
				Color c;
				if(_isTempoOnNote) {
					c = new Color(image.color.r, image.color.g, image.color.b, enabledAlpha);
				} else {
					c = new Color(image.color.r, image.color.g, image.color.b, disabledAlpha);
				}
				image.color = c;
			}
			get {
				return _isTempoOnNote;
			}
		}

		public void Reset() {
			Color c = new Color(image.color.r, image.color.g, image.color.b, disabledAlpha);
			image.color = c;
		}
	}
}