# The Bit Cave - Concerto per AI #
A project by Marco Secchi ([http://marcosecchi.it](http://marcosecchi.it)).

## Content ##
This package includes a full set of assets that can be used mainly in The Bit Cave tutorials, but also for your own personal projects.

All the assets have been created using [MagicaVoxel](https://voxel.codeplex.com/ "MagicaVoxel"): you can find the _.vox_ files in the _TheBitCave/ConcertoPerAI/MagicaVoxel_ folder.
